근더하기 - 갤럭시용 Android 앱 프로젝트

이 프로젝트는 기존 근더하기 HTML을 Android WebView 앱으로 감싼 소스입니다.
APK 빌드는 GitHub Actions 클라우드에서 실행할 수 있어 PC가 없어도 됩니다.

[휴대폰만으로 APK 받는 방법]
1. Android 휴대폰에서 https://github.com 에 접속해 무료 계정으로 로그인합니다.
2. 새 저장소(New repository)를 만듭니다. 이름은 geundadeo 로 하고 Public 또는 Private 중 선택합니다.
3. 이 ZIP 파일을 휴대폰의 파일 앱에서 압축 해제합니다.
4. GitHub 저장소에서 Add file > Upload files를 누릅니다.
5. 압축 해제된 geundadeo-android 폴더 안의 파일과 폴더를 저장소 최상위에 업로드합니다.
   중요: geundadeo-android 폴더 자체가 아니라 그 안의 파일/폴더(settings.gradle, app, .github 등)를 올려야 합니다.
   숨김 폴더 .github도 반드시 포함해야 자동 APK 빌드가 됩니다.
6. Commit changes를 누릅니다. main 브랜치에 업로드되면 클라우드 빌드가 자동 실행됩니다.
7. 저장소의 Actions 탭 > Build Geundadeo APK 실행 항목을 엽니다.
8. 완료되면 아래 Artifacts에서 Geundadeo-debug-apk를 눌러 ZIP을 다운로드합니다.
9. 다운로드한 ZIP을 압축 해제하고 app-debug.apk를 눌러 설치합니다.
10. Android에서 '출처를 알 수 없는 앱 설치' 권한을 허용하라는 메시지가 나오면 브라우저 또는 파일 앱에 허용한 뒤 설치합니다.

[참고]
- APK는 개인 설치용 디버그 서명 빌드입니다. Play 스토어 배포용 서명 APK가 아닙니다.
- Android 6.0 이상을 대상으로 합니다. 기기별 호환성은 설치 후 확인이 필요합니다.
- 앱 데이터는 앱 내부 WebView 저장소에 보관됩니다. 앱 삭제/데이터 삭제 전에는 CSV 내보내기로 백업하세요.
- GitHub 모바일 웹의 파일 업로드 화면에서 폴더 업로드가 지원되지 않는 경우, GitHub 앱/브라우저의 데스크톱 사이트 보기 또는 파일 선택 기능을 이용해야 할 수 있습니다.
